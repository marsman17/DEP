import React from "react";

const AddressCard = () => {
  return (
    <div>
      <br />
      <hr />
      <div className="space-y-4 text-gray-800 font-normal">
        <p className="text-xl pt-6">Muhammad Ahmad Naveed</p>
        <p>Model Town, Lahore, Punjab, 57400</p>
        <div className="space-y-1">03454114424</div>
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
      </div>
    </div>
  );
};

export default AddressCard;
