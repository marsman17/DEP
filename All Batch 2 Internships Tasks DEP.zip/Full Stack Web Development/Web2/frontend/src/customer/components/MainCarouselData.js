export const mainCarouselData = [
  {
    image:
      "https://outfitters.com.pk/cdn/shop/files/Multilink_M_DV_e054920b-a204-4256-b540-d2ccff8ba140.jpg?v=1719902495",
  },
  {
    image:
      "https://outfitters.com.pk/cdn/shop/files/DV_1920x900_W_14b74d30-98bd-4be5-b8c2-2cb438c2ab96.jpg?v=1719393865",
  },
  {
    image:
      "https://outfitters.com.pk/cdn/shop/files/DV_1920x900_M-1_7f8a02f5-8e4f-421f-b9eb-bfdf4558b656.jpg?v=1719394590",
    path: "/women/clothing/women_dress",
  },
  {
    image:
      "https://outfitters.com.pk/cdn/shop/files/Multilink_W_DV_ecd77371-f896-48b8-b901-c570d3d8427d.jpg?v=1719902477",
    path: "/women/clothing/women_saree",
  },
];
