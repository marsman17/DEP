import React from "react";

const CustomersTable = () => {
  return <div>CustomersTable</div>;
};

export default CustomersTable;
