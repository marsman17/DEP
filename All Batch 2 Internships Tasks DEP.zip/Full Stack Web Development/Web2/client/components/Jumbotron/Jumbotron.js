import React from "react";
import "./Jumbotron.scss";

export default function Jumbotron({ children }) {
  return <div className="jumbotron">{children}</div>;
}
