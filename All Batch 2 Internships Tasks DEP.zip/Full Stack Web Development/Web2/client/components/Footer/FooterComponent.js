import React from "react";
import "./Footer.scss";

export default function FooterComponent() {
  return (
    <div className="footer-component">© MERN Blog 2021 by Maryam Aljanabi</div>
  );
}
