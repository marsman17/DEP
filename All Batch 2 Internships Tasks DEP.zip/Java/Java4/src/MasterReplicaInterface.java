

public interface MasterReplicaInterface extends MasterInterface{
	
}
