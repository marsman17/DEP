import java.rmi.Remote;


public interface ReplicaInterface extends Remote {

}
