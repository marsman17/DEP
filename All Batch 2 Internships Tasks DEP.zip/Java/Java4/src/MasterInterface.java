import java.rmi.Remote;


public interface MasterInterface extends Remote {

}
